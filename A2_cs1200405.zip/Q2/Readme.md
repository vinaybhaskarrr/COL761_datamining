gSpan
