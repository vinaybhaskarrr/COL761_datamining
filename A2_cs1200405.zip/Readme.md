 Running sh Q1.sh <input_path> <result_path> should run all scripts for Q1, tak
ing as input the Yeast dataset kept at input path and save the generated plot at the
 result path. Name the plot file q1_plot_kerberosid.png.- Running sh Q2.sh <input_path> <result_path> should read the graphs from the in
put path and run all the pre-processing and feature generation scripts. The generated
 features should be saved in features_kerberosid.txt at the result path.
