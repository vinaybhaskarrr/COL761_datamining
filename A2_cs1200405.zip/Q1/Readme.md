bash Q1.sh <input_path> <result_path>
The final plot will be saved at result path.

